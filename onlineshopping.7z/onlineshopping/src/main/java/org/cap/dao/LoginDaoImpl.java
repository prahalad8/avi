package org.cap.dao;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import org.cap.model.LoginBean;

public class LoginDaoImpl implements ILoginDao {

	@Override
	public boolean isValidLogin(LoginBean bean) {
		String sql="select * from adminlogin where username = '"+bean.getUserName()+"' and userpassword = '"+bean.getUserPassword()+"'";

		try (
			Connection con=getMySQLDBConnection();	
				Statement st=con.createStatement();)
			{
			
			ResultSet resultSet= st.executeQuery(sql);	
			if(resultSet.next()) {
				return true;
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
			return false;
	}

	private Connection getMySQLDBConnection() {
		Connection connection=null;
		try {
			Class.forName("com.mysql.jdbc.Driver");
			connection=DriverManager.getConnection("jdbc:mysql://localhost:3306/capdb","root","India123");
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return connection;
		
	}

}
